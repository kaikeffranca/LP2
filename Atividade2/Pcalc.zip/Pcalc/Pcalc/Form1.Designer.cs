﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNum1 = new System.Windows.Forms.Label();
            this.LblNum2 = new System.Windows.Forms.Label();
            this.LblRes = new System.Windows.Forms.Label();
            this.BtnLim = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.BtnSoma = new System.Windows.Forms.Button();
            this.BtnSub = new System.Windows.Forms.Button();
            this.BtnMpy = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.TxtNum1 = new System.Windows.Forms.TextBox();
            this.TxtNum2 = new System.Windows.Forms.TextBox();
            this.TxtRes = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblNum1
            // 
            this.LblNum1.AutoSize = true;
            this.LblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNum1.Location = new System.Drawing.Point(41, 34);
            this.LblNum1.Name = "LblNum1";
            this.LblNum1.Size = new System.Drawing.Size(108, 25);
            this.LblNum1.TabIndex = 0;
            this.LblNum1.Text = "Número 1 :";
            // 
            // LblNum2
            // 
            this.LblNum2.AutoSize = true;
            this.LblNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNum2.Location = new System.Drawing.Point(41, 114);
            this.LblNum2.Name = "LblNum2";
            this.LblNum2.Size = new System.Drawing.Size(108, 25);
            this.LblNum2.TabIndex = 1;
            this.LblNum2.Text = "Número 2 :";
            // 
            // LblRes
            // 
            this.LblRes.AutoSize = true;
            this.LblRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRes.Location = new System.Drawing.Point(41, 196);
            this.LblRes.Name = "LblRes";
            this.LblRes.Size = new System.Drawing.Size(110, 25);
            this.LblRes.TabIndex = 2;
            this.LblRes.Text = "Resultado :";
            // 
            // BtnLim
            // 
            this.BtnLim.Location = new System.Drawing.Point(331, 34);
            this.BtnLim.Name = "BtnLim";
            this.BtnLim.Size = new System.Drawing.Size(75, 34);
            this.BtnLim.TabIndex = 7;
            this.BtnLim.Text = "Limpar";
            this.BtnLim.UseVisualStyleBackColor = true;
            this.BtnLim.Click += new System.EventHandler(this.BtnLim_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(331, 106);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 31);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // BtnSoma
            // 
            this.BtnSoma.Location = new System.Drawing.Point(42, 281);
            this.BtnSoma.Name = "BtnSoma";
            this.BtnSoma.Size = new System.Drawing.Size(75, 23);
            this.BtnSoma.TabIndex = 3;
            this.BtnSoma.Text = "+";
            this.BtnSoma.UseVisualStyleBackColor = true;
            this.BtnSoma.Click += new System.EventHandler(this.BtnSoma_Click);
            // 
            // BtnSub
            // 
            this.BtnSub.Location = new System.Drawing.Point(136, 281);
            this.BtnSub.Name = "BtnSub";
            this.BtnSub.Size = new System.Drawing.Size(75, 23);
            this.BtnSub.TabIndex = 4;
            this.BtnSub.Text = "-";
            this.BtnSub.UseVisualStyleBackColor = true;
            this.BtnSub.Click += new System.EventHandler(this.BtnSub_Click);
            // 
            // BtnMpy
            // 
            this.BtnMpy.Location = new System.Drawing.Point(234, 281);
            this.BtnMpy.Name = "BtnMpy";
            this.BtnMpy.Size = new System.Drawing.Size(75, 23);
            this.BtnMpy.TabIndex = 5;
            this.BtnMpy.Text = "x";
            this.BtnMpy.UseVisualStyleBackColor = true;
            this.BtnMpy.Click += new System.EventHandler(this.BtnMpy_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.Location = new System.Drawing.Point(331, 281);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(75, 23);
            this.BtnDiv.TabIndex = 6;
            this.BtnDiv.Text = "/";
            this.BtnDiv.UseVisualStyleBackColor = true;
            this.BtnDiv.Validated += new System.EventHandler(this.BtnDiv_Validated);
            // 
            // TxtNum1
            // 
            this.TxtNum1.Location = new System.Drawing.Point(178, 38);
            this.TxtNum1.Name = "TxtNum1";
            this.TxtNum1.Size = new System.Drawing.Size(100, 22);
            this.TxtNum1.TabIndex = 1;
            this.TxtNum1.Validated += new System.EventHandler(this.TxtNum1_Validated);
            // 
            // TxtNum2
            // 
            this.TxtNum2.Location = new System.Drawing.Point(178, 118);
            this.TxtNum2.Name = "TxtNum2";
            this.TxtNum2.Size = new System.Drawing.Size(100, 22);
            this.TxtNum2.TabIndex = 2;
            this.TxtNum2.Validated += new System.EventHandler(this.TxtNum2_Validated);
            // 
            // TxtRes
            // 
            this.TxtRes.Location = new System.Drawing.Point(178, 200);
            this.TxtRes.Name = "TxtRes";
            this.TxtRes.ReadOnly = true;
            this.TxtRes.Size = new System.Drawing.Size(100, 22);
            this.TxtRes.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 395);
            this.Controls.Add(this.TxtRes);
            this.Controls.Add(this.TxtNum2);
            this.Controls.Add(this.TxtNum1);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.BtnMpy);
            this.Controls.Add(this.BtnSub);
            this.Controls.Add(this.BtnSoma);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLim);
            this.Controls.Add(this.LblRes);
            this.Controls.Add(this.LblNum2);
            this.Controls.Add(this.LblNum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNum1;
        private System.Windows.Forms.Label LblNum2;
        private System.Windows.Forms.Label LblRes;
        private System.Windows.Forms.Button BtnLim;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.Button BtnSoma;
        private System.Windows.Forms.Button BtnSub;
        private System.Windows.Forms.Button BtnMpy;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.TextBox TxtNum1;
        private System.Windows.Forms.TextBox TxtNum2;
        private System.Windows.Forms.TextBox TxtRes;
    }
}

