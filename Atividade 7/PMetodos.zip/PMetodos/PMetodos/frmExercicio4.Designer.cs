﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.Frase = new System.Windows.Forms.Label();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnContaSpace = new System.Windows.Forms.Button();
            this.btnContAlfa = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(104, 34);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(458, 298);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            this.rchtxtFrase.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Frase
            // 
            this.Frase.AutoSize = true;
            this.Frase.Location = new System.Drawing.Point(54, 34);
            this.Frase.Name = "Frase";
            this.Frase.Size = new System.Drawing.Size(42, 16);
            this.Frase.TabIndex = 1;
            this.Frase.Text = "Frase";
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(614, 171);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(132, 28);
            this.btnContNum.TabIndex = 2;
            this.btnContNum.Text = "Conta Número";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.btnContNum_Click);
            // 
            // btnContaSpace
            // 
            this.btnContaSpace.Location = new System.Drawing.Point(614, 224);
            this.btnContaSpace.Name = "btnContaSpace";
            this.btnContaSpace.Size = new System.Drawing.Size(132, 45);
            this.btnContaSpace.TabIndex = 3;
            this.btnContaSpace.Text = "1º Espaço em Branco";
            this.btnContaSpace.UseVisualStyleBackColor = true;
            this.btnContaSpace.Click += new System.EventHandler(this.btnContaSpace_Click);
            // 
            // btnContAlfa
            // 
            this.btnContAlfa.Location = new System.Drawing.Point(614, 285);
            this.btnContAlfa.Name = "btnContAlfa";
            this.btnContAlfa.Size = new System.Drawing.Size(132, 47);
            this.btnContAlfa.TabIndex = 4;
            this.btnContAlfa.Text = "Conta Caracter Alfabético";
            this.btnContAlfa.UseVisualStyleBackColor = true;
            this.btnContAlfa.Click += new System.EventHandler(this.btnContAlfa_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PMetodos.Properties.Resources.Logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(634, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 119);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PMetodos.Properties.Resources.Fundo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnContAlfa);
            this.Controls.Add(this.btnContaSpace);
            this.Controls.Add(this.btnContNum);
            this.Controls.Add(this.Frase);
            this.Controls.Add(this.rchtxtFrase);
            this.DoubleBuffered = true;
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Label Frase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnContaSpace;
        private System.Windows.Forms.Button btnContAlfa;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}