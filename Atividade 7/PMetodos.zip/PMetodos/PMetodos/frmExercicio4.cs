﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnContNum_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for(var i=0; i < rchtxtFrase.Text.Length; i++) 
            { 
                if (char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contador++;
                }
            }

            MessageBox.Show($"Quantidade de Números: {contador}");
        }

        private void btnContAlfa_Click(object sender, EventArgs e)
        {
            int contador = 0; 

            foreach(char let in rchtxtFrase.Text)
            {
                if(char.IsLetter(let))
                {
                    contador++;
                }
            }

            MessageBox.Show($"Quantidade de Letras:{contador}");
        }

        private void btnContaSpace_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }

            MessageBox.Show($"O primeiro caracter branco está na posição: {posicao}");
        }
    }
}
