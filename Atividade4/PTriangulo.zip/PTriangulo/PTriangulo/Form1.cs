﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtB.Text, out b) || b <= 0)
            {
                MessageBox.Show("Valor inválido para o Lado B!");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtC.Text, out c) || c <= 0)
            {
                MessageBox.Show("Valor inválido para o Lado C!");
                txtC.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            /*if (!Double.TryParse(txtA.Text, out a) || a <= 0)
            {
                MessageBox.Show("O valor inválido do lado A foi ignorado!");
                txtA.Focus();
            }
            else if (!Double.TryParse(txtB.Text, out b) || b <= 0)
            {
                MessageBox.Show("O valor inválido do lado B foi ignorado!");
                txtB.Focus();
            }
            else if (!Double.TryParse(txtC.Text, out c) || c <= 0)
            {
                MessageBox.Show("O valor inválido do lado C foi ignorado!");
                txtC.Focus();
            }*/
            if ((Math.Abs(b - c) >= a || (b + c) <= a) && (Math.Abs(a - c) >= b || (a + c) <= b) || (Math.Abs(a - b) >= c || (a + b) <= c))
            {
                MessageBox.Show("Os valores não formam um triângulo!");
                txtTipTri.Clear();
                pbxTri.Image = imageList1.Images[3];
            }
            else if ((a == b) && (a == c))
            {
                txtTipTri.Text = "Triângulo Equilátero.";
                pbxTri.Image = imageList1.Images[0];
            }
            else if (((a == b) && (a != c)) || ((a == c) && (a != b)) || ((b == c) && (b != a)))
            {
                txtTipTri.Text = "Triângulo Isósceles.";
                pbxTri.Image = imageList1.Images[1];
            }
            else if ((a != b) && (a != c) && (b != c))
            {
                txtTipTri.Text = "Triângo Escaleno.";
                pbxTri.Image = imageList1.Images[2];
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtTipTri.Clear();

            if (txtTipTri.Text == "")
            {
                pbxTri.Image = imageList1.Images[3];
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtA.Text, out a) || a <= 0)
            {
                MessageBox.Show("Valor inválido para o Lado A!");
                txtA.Focus();
            }
        }
    }
}
