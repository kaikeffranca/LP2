﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.lblTipTri = new System.Windows.Forms.Label();
            this.txtTipTri = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.picbxLogo = new System.Windows.Forms.PictureBox();
            this.pbxTri = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picbxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTri)).BeginInit();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.Location = new System.Drawing.Point(27, 189);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(94, 29);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Lado A:";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblB.Location = new System.Drawing.Point(26, 232);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(95, 29);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "Lado B:";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblC.Location = new System.Drawing.Point(25, 276);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(96, 29);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "Lado C:";
            // 
            // txtA
            // 
            this.txtA.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtA.Location = new System.Drawing.Point(141, 186);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 34);
            this.txtA.TabIndex = 1;
            this.txtA.Validated += new System.EventHandler(this.txtA_Validated);
            // 
            // txtB
            // 
            this.txtB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB.Location = new System.Drawing.Point(141, 229);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(100, 34);
            this.txtB.TabIndex = 2;
            this.txtB.Validated += new System.EventHandler(this.txtB_Validated);
            // 
            // txtC
            // 
            this.txtC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtC.Location = new System.Drawing.Point(141, 273);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 34);
            this.txtC.TabIndex = 3;
            this.txtC.Validated += new System.EventHandler(this.txtC_Validated);
            // 
            // lblTipTri
            // 
            this.lblTipTri.AutoSize = true;
            this.lblTipTri.BackColor = System.Drawing.SystemColors.Control;
            this.lblTipTri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipTri.Location = new System.Drawing.Point(267, 191);
            this.lblTipTri.Name = "lblTipTri";
            this.lblTipTri.Size = new System.Drawing.Size(212, 29);
            this.lblTipTri.TabIndex = 6;
            this.lblTipTri.Text = "Tipo de Triângulo:";
            // 
            // txtTipTri
            // 
            this.txtTipTri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTipTri.Location = new System.Drawing.Point(494, 188);
            this.txtTipTri.Name = "txtTipTri";
            this.txtTipTri.ReadOnly = true;
            this.txtTipTri.Size = new System.Drawing.Size(272, 34);
            this.txtTipTri.TabIndex = 5;
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(543, 232);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(174, 39);
            this.btnCalc.TabIndex = 4;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(30, 400);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(126, 38);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(641, 400);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(126, 38);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // picbxLogo
            // 
            this.picbxLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picbxLogo.BackgroundImage")));
            this.picbxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbxLogo.Location = new System.Drawing.Point(30, 27);
            this.picbxLogo.Name = "picbxLogo";
            this.picbxLogo.Size = new System.Drawing.Size(197, 125);
            this.picbxLogo.TabIndex = 8;
            this.picbxLogo.TabStop = false;
            // 
            // pbxTri
            // 
            this.pbxTri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxTri.Image = global::PTriangulo.Properties.Resources.TipTri;
            this.pbxTri.Location = new System.Drawing.Point(529, 59);
            this.pbxTri.Name = "pbxTri";
            this.pbxTri.Size = new System.Drawing.Size(197, 123);
            this.pbxTri.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxTri.TabIndex = 9;
            this.pbxTri.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Equilátero.png");
            this.imageList1.Images.SetKeyName(1, "Isósceles.png");
            this.imageList1.Images.SetKeyName(2, "Escaleno.png");
            this.imageList1.Images.SetKeyName(3, "TipTri.png");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PTriangulo.Properties.Resources.Fundo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pbxTri);
            this.Controls.Add(this.picbxLogo);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtTipTri);
            this.Controls.Add(this.lblTipTri);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picbxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTri)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Label lblTipTri;
        private System.Windows.Forms.TextBox txtTipTri;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox picbxLogo;
        private System.Windows.Forms.PictureBox pbxTri;
        private System.Windows.Forms.ImageList imageList1;
    }
}

