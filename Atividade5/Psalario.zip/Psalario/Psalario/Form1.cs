﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salBruto, AliqINSS, AliqIRPF, SalFamilia, DescINSS, DescIRPF, SalLiq;
        decimal qtdFilhos;

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                MessageBox.Show("Números não são permitidos no campo destinado ao nome!");
                SendKeys.Send("{BACKSPACE}");

            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesc_Click(object sender, EventArgs e)
        {
            /*string verif;

            for(int cont = 0; cont <= 9; cont++)
            {
                verif = cont.ToString ();
                if (txtNome.Text.Contains(verif))
                {
                    MessageBox.Show("Números não podem ser escritos em nomes!");
                }
            }*/
            
            if(!Double.TryParse(mskbxSalBruto.Text, out salBruto) ||(  salBruto <= 0))
            {
                MessageBox.Show("Valor de Salário Invalido!\nPor favor informe um número!");
                mskbxSalBruto.Clear();
                mskbxSalBruto.Focus();
            }
            
            if(salBruto <= 800.47)
            {
                txtAliqINSS.Text = "7,65%";
                DescINSS = (7.65 / 100) * salBruto;
                txtDescINSS.Text = DescINSS.ToString("C");
            }
            else if((salBruto > 800.47) && (salBruto <= 1050))
            {
                txtAliqINSS.Text = "8,65%";
                DescINSS = ((8.65 / 100) * salBruto);
                txtDescINSS.Text = DescINSS.ToString("C");
            }
            else if((salBruto > 1050) && (salBruto <= 1400.77)) 
            {
                txtAliqINSS.Text = "9,00%";
                DescINSS = ((9.00 / 100) * salBruto);
                txtDescINSS.Text = DescINSS.ToString("C");
            }
            else if((salBruto > 1400.77) && (salBruto <= 2801.56))
            {
                txtAliqINSS.Text = "11,00%";
                DescINSS = ((11.00 / 100) * salBruto);
                txtDescINSS.Text = DescINSS.ToString("C");
            }
            else 
            {
                txtAliqINSS.Text = "Teto";
                DescINSS = 308.17;
                txtDescINSS.Text = DescINSS.ToString("C");
            }


            if(salBruto <= 1257.12)
            {
                txtAliqIRPF.Text = "Isento";
                DescIRPF = 0;
                txtDescIRPF.Text = DescIRPF.ToString("C");

            }
            else if((salBruto > 1257.12) && (salBruto <= 2512.08 ))
            {
                txtAliqIRPF.Text = "15.00%";
                DescIRPF = ((15.00 / 100) * salBruto);
                txtDescIRPF.Text = DescIRPF.ToString("C");
            }
            else
            {
                txtAliqIRPF.Text = "27.5%";
                DescIRPF = ((27.50 / 100) * salBruto);
                txtDescIRPF.Text = DescIRPF.ToString("C");
            }

            if(salBruto <= 435.52 )
            {
                SalFamilia = (double)nupdFilhos.Value * 22.33;
                txtSalFamilia.Text = SalFamilia.ToString("C");
            }
            else if((salBruto > 435.52) && (salBruto <= 654.61))
            {
                SalFamilia = (double)nupdFilhos.Value * 15.74;
                txtSalFamilia.Text = SalFamilia.ToString("C");
            }
            else
            {
                SalFamilia = 0;
                txtSalFamilia.Text = SalFamilia.ToString("C");
            }

            salBruto = salBruto - DescINSS - DescIRPF + SalFamilia;
            txtSalLiq.Text = salBruto.ToString("C");

        }
    }
}
