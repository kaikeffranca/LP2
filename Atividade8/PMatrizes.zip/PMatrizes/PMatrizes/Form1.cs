﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for(var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um nº para posição: {i + 1}");
                if(!int.TryParse( auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            
            /*Array.Reverse(vetor);
            auxiliar = "";
            foreach(int i in vetor)
            {
                auxiliar += i + "\n";
            }

            MessageBox.Show(auxiliar);*/
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            double[] media = new double[20];
            string auxiliar = "";
            string imprimir = "";
            double soma = 0.0;
            double med = 0.0;

            for(var i = 0;i < 20;i++)
            {
                for(var j = 0;j < notas.GetLength(1);j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ");
                    if(!double.TryParse( auxiliar,out notas[i, j]) || (notas[i,j] < 0) || (notas[i,j] > 10))
                    {
                        MessageBox.Show("Mensagem Inválida!");
                        j--;
                    }
                    else
                    {
                        soma = soma + notas[i,j];
                    }
                }
                med = soma / 3;
                media[i] = med;
                imprimir = imprimir + "Aluno " + (i + 1) + " :" + "Média : " + media[i].ToString("N2") + "\n" ;
                soma = 0;
                med = 0;
            }

            MessageBox.Show(imprimir);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string imprimir = "";

            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janette");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otávio");
            foreach(string lista in nomes)
            {
                imprimir += lista + "\n";
            }

            MessageBox.Show(imprimir);
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }
    }
}
