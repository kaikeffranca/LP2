﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPeso, "");

            if(!double.TryParse(mskbxPeso.Text, out peso)||(peso <= 0)) 
            {
                MessageBox.Show("Peso Inválido!");
                errorProvider1.SetError(mskbxPeso, "Peso Inválido!");
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            double altura;
            errorProvider2.SetError(mskbxAltura, "");

            if(!double.TryParse(mskbxAltura.Text, out altura)||(altura <= 0)) 
            {
                MessageBox.Show("Altura Inválida!");
                errorProvider2.SetError(mskbxAltura, "Altura Inválida!");
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double altura, peso, imc;

            if(Double.TryParse(mskbxPeso.Text, out peso) && Double.TryParse(mskbxAltura.Text, out altura))
            {
                if (altura <= 0 || peso <= 0)
                {
                    MessageBox.Show("Os valores devem ser maiores que zero!");
                }
                else
                {
                    imc = peso / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1); //Math.Round (imc, 1) para arredondar com uma casa.
                    txtIMC.Text = imc.ToString("");

                    if(imc < 18.5)
                    {
                        txtIMC.Text += " Classificação: Magreza";
                    }
                    else if(imc <= 24.9)
                    {
                        txtIMC.Text += " Classificação: Normal";
                    }
                    else if(imc <= 29.9) 
                    {
                        txtIMC.Text += " Classificação: Sobrepeso";
                    }
                    else if(imc <= 39.9)
                    {
                        txtIMC.Text += " Classificação: Obesidade";
                    }
                    else
                    {
                        txtIMC.Text += " Classificação: Obesidade Grave";
                    }
                }
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLim_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
         
        }
    }
}
