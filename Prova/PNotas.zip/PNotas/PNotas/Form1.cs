﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerify_Click(object sender, EventArgs e)
        {
            string[] gabarito = {"A", "D", "C", "A", "A", "B", "C",
            "E", "E", "D"};
            string[,] alunos = new string[10, 4];
            string auxiliar = " ";

            for (var col = 0; col < 4; col++)
            {
                for (var lin = 0; lin < 10; lin++)
                {
                    auxiliar = Interaction.InputBox($"Resposta do aluno {col + 1} para a questão {lin + 1}: ");
                    if ((auxiliar == "A") || (auxiliar == "B") || (auxiliar == "C") || (auxiliar == "D") || (auxiliar == "E"))
                    {
                        alunos[lin, col] = auxiliar;
                        if (alunos[lin, col] == gabarito[lin])
                        {
                            auxiliar = "O aluno " + (col + 1) + " acertou a questão " + (lin + 1) + " era " + gabarito[lin] + " escolheu "
                                + auxiliar + "\n";
                        }
                        else
                        {
                            auxiliar = "O aluno " + (col + 1) + " errou a questão " + (lin + 1) + " era " + gabarito[lin] + " escolheu "
                                + auxiliar + "\n";
                        }

                        lsbxNotas.Items.Add(auxiliar);
                    }
                    else
                    {
                        MessageBox.Show("Digite uma alternativa válida!!");
                        lin--;
                    }
                }
            }
        }
    }
}
