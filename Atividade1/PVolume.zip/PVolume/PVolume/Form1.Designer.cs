﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblRaio = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtRaio = new System.Windows.Forms.TextBox();
            this.TxtAltura = new System.Windows.Forms.TextBox();
            this.TxtVolume = new System.Windows.Forms.TextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblRaio
            // 
            this.LblRaio.AutoSize = true;
            this.LblRaio.Location = new System.Drawing.Point(103, 52);
            this.LblRaio.Name = "LblRaio";
            this.LblRaio.Size = new System.Drawing.Size(39, 16);
            this.LblRaio.TabIndex = 0;
            this.LblRaio.Text = "Raio:";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(103, 105);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(44, 16);
            this.LblAltura.TabIndex = 1;
            this.LblAltura.Text = "Altura:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Volume:";
            // 
            // TxtRaio
            // 
            this.TxtRaio.Location = new System.Drawing.Point(174, 49);
            this.TxtRaio.Name = "TxtRaio";
            this.TxtRaio.Size = new System.Drawing.Size(100, 22);
            this.TxtRaio.TabIndex = 1;
            this.TxtRaio.Validated += new System.EventHandler(this.TxtRaio_Validated);
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(174, 102);
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(100, 22);
            this.TxtAltura.TabIndex = 2;
            this.TxtAltura.Validated += new System.EventHandler(this.TxtAltura_Validated);
            // 
            // TxtVolume
            // 
            this.TxtVolume.Location = new System.Drawing.Point(174, 177);
            this.TxtVolume.Name = "TxtVolume";
            this.TxtVolume.ReadOnly = true;
            this.TxtVolume.Size = new System.Drawing.Size(100, 22);
            this.TxtVolume.TabIndex = 6;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(89, 251);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(75, 23);
            this.BtnCalcular.TabIndex = 3;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(263, 251);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 4;
            this.BtnClose.Text = "Fechar";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 347);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.TxtVolume);
            this.Controls.Add(this.TxtAltura);
            this.Controls.Add(this.TxtRaio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblRaio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblRaio;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtRaio;
        private System.Windows.Forms.TextBox TxtAltura;
        private System.Windows.Forms.TextBox TxtVolume;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtnClose;
    }
}

